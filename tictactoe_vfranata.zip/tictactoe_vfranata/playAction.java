package tictactoe_vfranata;
import java.util.Scanner;

public class playAction {
	    public static void main(String[] args)
	    {
	        Scanner scan = new Scanner(System.in);
	        TicTacToe t3Game = new TicTacToe();
	        TicTacToeVO t3VO = new TicTacToeVO();
	        int t3row = 0;
	        int t3col = 0;
	        t3VO = t3Game.declareBoard();
	        t3row = t3VO.getRows();
	        t3col = t3VO.getCols();
	        do{
	            if(t3row > 2 && t3col > 2){
	            	t3Game.initializeBoardGame(t3row, t3col);
	            	System.out.println("Tic Tac Toe!");
	            	System.out.println("Current board layout:");
		            t3Game.printBoardGame(t3row, t3col);
		            int row;
		            int col;
		            do
		            {
		                System.out.println("Player " + t3Game.getCurrentPlayerSign() + ", please enter an empty row and column to place your mark!");
		                row = scan.nextInt()-1;
		                col = scan.nextInt()-1;
		            }
		            while (!t3Game.placeSign(row, col, t3VO));
		            t3Game.changePlayer();
	            }else{
	            	break;
	            }
	        }
	        while(!t3Game.checkForWin(t3row, t3col) && !t3Game.isBoardFull(t3row, t3col));
	        if (t3Game.isBoardFull(t3row, t3col) && !t3Game.checkForWin(t3row, t3col))
	        {
	            System.out.println("The game was DRAW!");
	        }
	        else
	        {
	            System.out.println("Current board screen:");
	            t3Game.printBoardGame(t3row, t3col);
	            t3Game.changePlayer();
	            System.out.println(Character.toUpperCase(t3Game.getCurrentPlayerSign()) + " is the WINNER!");
	        }
	    }
}
