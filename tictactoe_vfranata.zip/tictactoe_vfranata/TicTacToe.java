package tictactoe_vfranata;

import java.util.Scanner;

public class TicTacToe {

    private char[][] board;
    private char currentPlayerSign;

    public TicTacToe() {
        currentPlayerSign = 'x';
    }

    //Gives us access to currentPlayerSign
    public char getCurrentPlayerSign()
    {
        return currentPlayerSign;
    }

    //to declare dynamic board by input user
    public TicTacToeVO declareBoard(){
    	int row;
    	int col;
    	Scanner in = new Scanner(System.in);
    	TicTacToeVO t3VO = new TicTacToeVO();
    	
    	System.out.println("Enter how many row?");
        row = in.nextInt();
        System.out.println("Enter how many column?");
        col = in.nextInt();
        if(row < 3){
        	if(col < 3){
        		System.out.println("Please input more than 2 columns & 2 rows");
        		System.out.println("Enter how many row?");
        		row = in.nextInt();
        		System.out.println("Enter how many column?");
        		col = in.nextInt();
        	}else{
        		System.out.println("Please input more than 2 rows");
        		row = in.nextInt();
        	}
        }else if(col < 3){
        	System.out.println("Please input more than 2 columns");
        	col = in.nextInt();
        }
        
        if((row > 2 && col > 2)){
        	System.out.println("We Are Set!");
        	t3VO.setCols(col);
        	t3VO.setRows(row);
        	System.out.println("You entered " + row + " rows");
        	System.out.println("You entered " + col + " columns");
        }else{
        	System.out.println("Game End, Input wrong");
        	return t3VO;
        }
        
        return t3VO;
    	
    }
    // Set/Reset the board back to all empty values.
    public void initializeBoardGame(int row, int col) {
    	board = new char[row][col];
        // Loop through rows
        for (int i = 0; i < row; i++) {

            // Loop through columns
            for (int j = 0; j < col; j++) {
                board[i][j] = '-';
            }
        }
    }


    // Print the current board (may be replaced by GUI implementation later)
    public void printBoardGame(int row, int col) {
        System.out.println("-----------------------------------");

        for (int i = 0; i < row; i++) {
            System.out.print("| ");
            for (int j = 0; j < col; j++) {
                System.out.print(board[i][j] + " | ");
            }
            System.out.println();
            System.out.println("-----------------------------------");
        }
    }


    // Loop through all cells of the board and if one is found to be empty (contains char '-') then return false.
    // Otherwise the board is full.
    public boolean isBoardFull(int row, int col) {
        boolean isFull = true;

        for (int i = 0; i < row; i++) {
            for (int j = 0; j < col; j++) {
                if (board[i][j] == '-') {
                    isFull = false;
                }
            }
        }

        return isFull;
    }


    // Returns true if there is a win, false otherwise.
    // This calls our other win check functions to check the entire board.
    public boolean checkForWin(int row, int col) {
        return (checkRowsForWin(row) || checkColumnsForWin(col) || checkDiagonalsForWin(row, col));
    }


    // Loop through rows and see if any are winners.
    private boolean checkRowsForWin(int row) {
        for (int i = 0; i < row; i++) {
            if (checkRowCol(board[i][row]) == true) {
                return true;
            }
        }
        return false;
    }


    // Loop through columns and see if any are winners.
    private boolean checkColumnsForWin(int col) {
        for (int i = 0; i < col; i++) {
            if (checkRowCol(board[col][i]) == true) {
                return true;
            }
        }
        return false;
    }


    // Check the two diagonals to see if either is a win. Return true if either wins.
    private boolean checkDiagonalsForWin(int row, int col) {
        return ((checkRowCol(board[row][col]) == true));
    }


    // Check to see if all three values are the same (and not empty) indicating a win.
    private boolean checkRowCol(char c1) {
        return ((c1 != '-'));
    }


    // Change player marks back and forth.
    public void changePlayer() {
        if (currentPlayerSign == 'x') {
            currentPlayerSign = 'o';
        }
        else {
            currentPlayerSign = 'x';
        }
    }

    // Places a mark at the cell specified by row and col with the sign of the current player.
    public boolean placeSign(int row, int col, TicTacToeVO t3VO) {

        // Make sure that row and column are in bounds of the board.
        if ((row >= 0) && (row < t3VO.getRows())) {
            if ((col >= 0) && (col < t3VO.getCols())) {
                if (board[row][col] == '-') {
                    board[row][col] = currentPlayerSign;
                    return true;
                }
            }
        }

        return false;
    }
}